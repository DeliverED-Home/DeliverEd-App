package com.example.delivered;

public interface ItemTouchHelperAdapter {
    public void onItemMove(int fromPosition,int toPosition);
    public void onItemDelete(int position);
}
